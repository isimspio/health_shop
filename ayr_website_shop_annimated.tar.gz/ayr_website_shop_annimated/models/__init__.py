# -*- coding: utf-8 -*-

import medical
